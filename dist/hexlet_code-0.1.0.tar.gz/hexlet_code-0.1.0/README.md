### Hexlet tests and linter status:
[![Actions Status](https://github.com/Smacktur/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Smacktur/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/05b5267a355b316f918f/maintainability)](https://codeclimate.com/github/Smacktur/python-project-49/maintainability)